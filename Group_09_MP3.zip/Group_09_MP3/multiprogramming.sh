nice ./work 200 R 10000 &
nice ./work 200 R 10000 &
nice ./work 200 R 10000 &
nice ./work 200 R 10000 &
nice ./work 200 R 10000 &
nice ./work 200 R 10000 &
nice ./work 200 R 10000 &
